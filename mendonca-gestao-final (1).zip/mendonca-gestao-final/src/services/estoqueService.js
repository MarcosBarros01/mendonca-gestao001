export async function fetchProducts(){ return []; }
export async function fetchVendas(){ return []; }
