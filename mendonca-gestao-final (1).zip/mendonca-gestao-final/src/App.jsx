import React from 'react';
import './styles.css';
export default function App(){
  return (
    <div style={{padding:20}}>
      <h1>Mendonça Gestão - Ready</h1>
      <p>Abra o console para instruções. Deploy em Vercel configurado.</p>
    </div>
  );
}
