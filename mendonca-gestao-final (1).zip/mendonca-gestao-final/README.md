Mendonça - Gestão de Estoque (Final Package)

Este pacote contém todo o sistema pronto para deploy na Vercel e uso com Firebase Firestore.
Siga as instruções em README_DEPLOY.md
